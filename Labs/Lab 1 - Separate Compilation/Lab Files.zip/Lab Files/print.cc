#include <iostream>

using namespace std;

void printData(int data[],int nItems) {
  int i;

  for (i=0;i<nItems;i++)
    cout << data[i] << endl;
}
