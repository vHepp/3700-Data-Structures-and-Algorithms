#include "simpleStack.h"

void Stack::push(const StackType &d) {

  if (count == STACK_SIZE)
    throw std::overflow_error("SimpleStack");

  data[count] = d;

  count++;

// data[count++] = d;
}

StackType Stack::pop(void) {

  if (!count)
    throw std::underflow_error("SimpleStack");

  count--;

  return data[count];

// return data[--count];
}

StackType Stack::peek(void) {

  if (!count)
    throw std::underflow_error("SimpleStack");

  return data[count-1];
}
