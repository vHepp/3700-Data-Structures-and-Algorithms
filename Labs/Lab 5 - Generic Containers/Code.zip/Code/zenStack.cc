#include "zenStack.h"

void ZenStack::push(void *p) {

  if (count == STACK_SIZE)
    throw std::overflow_error("ZenStack");

  memcpy(data+count*dSize,p,dSize);

  count++;
}

void ZenStack::pop(void *p) throw (ContainerEmptyException) {

  if (count == 0)
    throw std::underflow_error("ZenStack");

  count--;

  memcpy(p,data+count*dSize,dSize);
}

void ZenStack::peek(void *p) throw (ContainerEmptyException) {

  if (count == 0)
    throw std::underflow_error("ZenStack");

  memcpy(p,data+(count-1)*dSize,dSize);
}
